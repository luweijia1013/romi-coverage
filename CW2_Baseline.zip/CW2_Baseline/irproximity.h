#ifndef _IRProximity_h
#define _IRProximity_h

class SharpIR
{
    public:
        SharpIR(byte pin, float _param1, float _param2);
        float  getDistanceRaw();
        float  getDistanceInMM();
        void calibrate();
        float read_calibrated();
        float lowpass_filter();
        
        float y;
        float alpha = 0.900;
        float const anlg2volt = 0.0048828125; //(5/1024)
    
    private:
        byte pin;
        float param1;
        float param2;
};

SharpIR::SharpIR(byte _pin, float _param1, float _param2)
{
  pin = _pin;
  param1 = _param1;
  param2 = _param2;
}

float SharpIR::getDistanceRaw()
{
    return analogRead(pin);
}

float SharpIR::read_calibrated()
{
  return lowpass_filter()*anlg2volt;
}

float SharpIR::lowpass_filter()
{
  y = alpha*y + (1-alpha) * getDistanceRaw();

  return y;
}

/*
 * This piece of code is quite crucial to mapping
 * obstacle distance accurately, so you are encouraged
 * to calibrate your own sensor by following the labsheet.
 * Also remember to make sure your sensor is fixed to your
 * Romi firmly and has a clear line of sight!
 */
float SharpIR::getDistanceInMM()
{
    const float exponent = (1/param2);
    float distance = pow( ( read_calibrated() / param1 ), exponent);
       
    return distance;
}


#endif

